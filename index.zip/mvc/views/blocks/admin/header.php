<div class="btn bg-dark d-flex align-items-center justify-content-center btn-special">
        <span class="fas fa-bars"></span>
    </div>
    <nav class="sidebar-sub">
        <h1 class="text">
            ADMIN
        </h1>
        <ul class="p-0">
            <li class="active"><a href="home">Dashboard</a></li>
            <li>
                <a href="javascript:void(0)" class="first-btn">Quản lí hàng hóa
                    <span class="fas fa-caret-down first"></span>
                </a>
                <ul class="first-show">
                    <li><a href="hanghoa/ThemHangHoa"><i class="fa-solid fa-square-plus"></i>&nbsp Tạo mới</a></li>
                    <li><a href="hanghoa"><i class="fa-sharp fa-solid fa-pen-to-square"></i>&nbsp Xem</a></li>

                </ul>
            </li>
            <li>
                <a href="javascript:void(0)" class="second-btn">Quản lí danh mục
                    <span class="fas fa-caret-down second"></span>
                </a>
                <ul class="second-show">
                    <li><a href="loai/Themloai"><i class="fa-solid fa-square-plus"></i>&nbsp Tạo mới</a></li>
                    <li><a href="loai"><i class="fa-sharp fa-solid fa-pen-to-square"></i>&nbsp Xem</a></li>
                </ul>
            </li>
            <li>
                <a href="javascript:void(0)" class="third-btn">Quản lí khách hàng
                    <span class="fas fa-caret-down third"></span>
                </a>
                <ul class="third-show">
                    <li><a href="khachhang/ThemKH"><i class="fa-solid fa-square-plus"></i>&nbsp Tạo mới</a></li>
                    <li><a href="khachhang"><i class="fa-sharp fa-solid fa-pen-to-square"></i>&nbsp Xem</a></li>
                </ul>
            </li>
            <li>
                <a href="javascript:void(0)" class="fourth-btn">Quản lí tin tức
                    <span class="fas fa-caret-down fourth"></span>
                </a>
                <ul class="fourth-show">
                    <li><a href="news/ThemNews"><i class="fa-solid fa-square-plus"></i>&nbsp Tạo mới</a></li>
                    <li><a href="news"><i class="fa-sharp fa-solid fa-pen-to-square"></i>&nbsp Xem</a></li>
                </ul>
            </li>
            <li>
                <a href="javascript:void(0)" class="fifth-btn">Quản lí bình luận
                    <span class="fas fa-caret-down fifth"></span>
                </a>
                <ul class="fifth-show">
                    <li><a href="binhluan"><i class="fa-sharp fa-solid fa-pen-to-square"></i>&nbsp Xem</a></li>
                </ul>
            </li>
            <li>
                <a href="javascript:void(0)" class="sixth-btn">Quản lí hóa đơn
                    <span class="fas fa-caret-down sixth"></span>
                </a>
                <ul class="sixth-show">
                    <li><a href="javascript:void(0)"><i class="fa-solid fa-square-plus"></i>&nbsp Tạo mới</a></li>
                    <li><a href="donhang/SayHi/1"><i class="fa-sharp fa-solid fa-pen-to-square"></i>&nbsp Xem</a></li>
                </ul>
            </li>
            <li>
        </ul>
    </nav>