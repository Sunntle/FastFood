<?php
require_once "./mvc/core/app.php";
require_once "./mvc/core/controller.php";
require_once "./mvc/core/db.php";
?>